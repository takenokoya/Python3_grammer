from setuptools import setup

setup(
    name='python_programming',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='https://example.com',
    license='free',
    author='sakaguchitakuya',
    author_email='takuya1002@gmail.com',
    description=''
)
